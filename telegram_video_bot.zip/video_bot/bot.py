import asyncio
import logging
import os
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import yt_dlp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import FSInputFile, Message

TOKEN = os.environ["BOT_TOKEN"]
MAX_BYTES = 45 * 1024 * 1024
semaphore = asyncio.Semaphore(2)
dp = Dispatcher()


def supported(url: str) -> bool:
    try:
        parsed = urlparse(url.strip())
        host = (parsed.hostname or "").lower()
        return parsed.scheme in {"https", "http"} and (
            host in {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "instagram.com", "www.instagram.com"}
        )
    except ValueError:
        return False


def download(url: str, folder: str) -> Path:
    options = {
        "format": "best[ext=mp4][height<=720]/best[height<=720]/best",
        "outtmpl": os.path.join(folder, "%(id)s.%(ext)s"),
        "noplaylist": True,
        "max_filesize": MAX_BYTES,
        "merge_output_format": "mp4",
        "socket_timeout": 20,
        "retries": 2,
        "quiet": True,
        "no_warnings": True,
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=True)
        if info is None:
            raise ValueError("Видео не найдено")
    files = [p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm"}]
    if not files:
        raise ValueError("Не удалось получить видеофайл")
    result = max(files, key=lambda p: p.stat().st_size)
    if result.stat().st_size > MAX_BYTES:
        raise ValueError("Видео слишком большое (лимит 45 МБ)")
    return result


@dp.message(CommandStart())
async def start(message: Message):
    await message.answer("👋 Привет! Отправь ссылку на публичное видео YouTube, Shorts или Instagram Reels. Я попробую скачать его и отправить сюда.")


@dp.message(F.text)
async def handle_link(message: Message):
    url = message.text.strip()
    if not supported(url):
        await message.answer("Пришли полную ссылку на YouTube или Instagram (https://...).")
        return
    status = await message.answer("⏳ Скачиваю видео, подожди немного…")
    async with semaphore:
        try:
            with tempfile.TemporaryDirectory() as folder:
                file = await asyncio.wait_for(asyncio.to_thread(download, url, folder), timeout=180)
                await message.answer_video(FSInputFile(file), supports_streaming=file.suffix.lower() == ".mp4")
            await status.delete()
        except Exception as exc:
            logging.warning("Download/send failed: %s", exc)
            await status.edit_text("❌ Не удалось скачать или отправить видео. Проверь, что оно публичное, доступно без входа и не слишком большое (до 45 МБ).")


async def main():
    logging.basicConfig(level=logging.INFO)
    bot = Bot(token=TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
