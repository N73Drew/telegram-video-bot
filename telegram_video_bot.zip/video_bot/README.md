# Telegram Video Bot

Accepts public YouTube and Instagram video URLs and attempts to return video files. Only download videos you have permission to download and comply with applicable platform rules.

## Railway deployment

1. Create a GitHub repository and upload `bot.py`, `requirements.txt`, `Dockerfile`, `.gitignore` (do not upload a bot token).
2. In Railway, create a project from the GitHub repository.
3. Under the Railway service **Variables**, add `BOT_TOKEN` with the token from BotFather.
4. Deploy. The Dockerfile starts the Telegram bot using polling; no public domain is required.
5. Check **Deploy Logs** for errors. Test with `/start` and a public video URL.

The Telegram Bot API has upload size limits; this example limits files to 45 MB. Instagram and YouTube may block downloads or require authentication. Some downloads may fail; this is expected. Railway hosting may cost money.
